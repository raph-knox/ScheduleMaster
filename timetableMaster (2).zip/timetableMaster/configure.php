<?php
define('DB_SERVER','localhost');
define('DB_USER','mertndll_bbv');
define('DB_PASS' ,'tomtom1000000');
define('DB_NAME', 'mertndll_bbv');
$db = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME); //or die('localhost connection problem'.mysql_error());
//mysql_select_db(DB_NAME, $conn);
	?>